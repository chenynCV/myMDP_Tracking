%date:2016-5-31
%author:chenyanan
%ת����ע��������http://blog.csdn.net/u010278305

%% Initialization
clear all; close all; clc
% seq_all={'01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14'};
seq_all={'04', '05', '06'};
for seq_i=1:numel(seq_all)
    seq_name=seq_all{seq_i};
    dataDir=['det/' seq_name '/'];
    picNameFormat='%06d';
    time_interval=4;
    
    %% sort
    fclose('all');
    fileName=['det/' seq_name '.txt'];
    if exist(fileName,'file')
        delete(fileName);
    end
    
    fid = fopen(fileName,'a');
    
    % start_frame=1;
    % end_frame=26997;
    listing = dir(fullfile(dataDir,'*.mat'));
    name=sscanf([listing.name], '%d.mat');
    start_frame=min(name);
    end_frame=max(name);
    for i=start_frame:time_interval:end_frame
        
        matName = fullfile(dataDir, [num2str(i,picNameFormat) '.mat']);       
        if ~exist(matName, 'file')
            continue;
        end       
        load([dataDir num2str(i,picNameFormat) '.mat']);
        %partbox=resu.partbox;
        
        % file
        for j=1:size(partbox,1)
            fprintf(fid,'%s,-1,%s,%s,%s,%s,%s,-1,-1,-1\n',...
                num2str(i),  num2str(partbox(j,1)), num2str(partbox(j,2)),...
                num2str(partbox(j,3)-partbox(j,1)),num2str(partbox(j,4)-partbox(j,2)),...
                num2str(partbox(j,5)));
        end
        
        %         % file
        %         for j=1:time_interval
        %             for k=1:size(partbox,1)
        %                 if i+j-1>end_frame
        %                     break;
        %                 end
        %                 fprintf(fid,'%s,-1,%s,%s,%s,%s,%s,-1,-1,-1\n',...
        %                     num2str(i+j-1),  num2str(partbox(k,1)), num2str(partbox(k,2)),...
        %                     num2str(partbox(k,3)-partbox(k,1)), num2str(partbox(k,4)-partbox(k,2)),...
        %                     num2str(partbox(k,5)));
        %             end
        %         end
        
    end
    
    fclose(fid);
    fclose('all');
    
    disp(seq_i);
end



