%date:2016-6-10
%author:chenyanan
%ת����ע��������http://blog.csdn.net/u010278305

function trackInterp(seqName, time_interval, opt)

resultDir=opt.results;
finalDir=opt.final_results;

fprintf('seqName:%s.   \n',seqName);

%% read file
detections=load(fullfile(resultDir, [seqName '.txt']));
if isempty(detections)
    return;
end
    
detections(:,1)=time_interval*(detections(:,1)-1)+1;

%% interp
tic
minId=min(detections(:,2));
maxId=max(detections(:,2));
detectionsInterp=[];
for i=minId:maxId
    detection_now=detections(detections(:,2)==i,:);
    if size(detection_now,1)>=2
        x=detection_now(:,1);
        v=detection_now(:,3:7);
        xq=min(x):max(x);
        if numel(xq)~=numel(x)
            vq = interp1(x,v,xq);
            xLength=numel(xq);
            detection_now=[xq(:), i*ones(xLength,1), vq, -1*ones(xLength,3)];
        end
    end
    detectionsInterp=[detectionsInterp; detection_now];
end
detections=detectionsInterp;

%% save
fclose('all');
if exist(fullfile(finalDir,[seqName '.txt']),'file')
    delete(fullfile(finalDir,[seqName '.txt']));
end

dlmwrite(fullfile(finalDir,[seqName '.txt']),detections)

elapsedTime=toc;

fprintf('elapsedTime=%f\n',elapsedTime);

end


% % release trackers according to lost time
% function result=trackeResultInterp(dres_track)
% minId=min(dres_track.id(:));
% maxId=max(dres_track.id(:));
% frInterp=[];
% idInterp=[];
% xInterp=[];
% yInterp=[];
% wInterp=[];
% hInterp=[];
% rInterp=[];
% stateInterp=[];
% for i=minId:maxId
%     index_now=dres_track.id(:)==i;
%     if sum(index_now)>=2
%         fr_now=double(dres_track.fr(index_now));
%         x_now=dres_track.x(index_now);
%         y_now=dres_track.y(index_now);
%         w_now=dres_track.w(index_now);
%         h_now=dres_track.h(index_now);
%         r_now=dres_track.r(index_now);
%         state_now=dres_track.state(index_now);
%         fr_q=min(fr_now):max(fr_now);
%         fr_q=fr_q(:);
%         if numel(fr_q)~=numel(fr_now)
%             x_q=interp1(fr_now,x_now,fr_q);
%             y_q=interp1(fr_now,y_now,fr_q);
%             w_q=interp1(fr_now,w_now,fr_q);
%             h_q=interp1(fr_now,h_now,fr_q);
%             r_q=interp1(fr_now,r_now,fr_q);
%             state_q=interp1(fr_now,state_now,fr_q, 'nearest');
%             frLength=numel(fr_q);
%             frInterp=[frInterp; fr_q];
%             idInterp=[idInterp; i*ones(frLength,1)];
%             xInterp=[xInterp; x_q];
%             yInterp=[yInterp; y_q];
%             wInterp=[wInterp; w_q];
%             hInterp=[hInterp; h_q];
%             rInterp=[rInterp; r_q];
%             stateInterp=[stateInterp; state_q];
%         else
%             frInterp=[frInterp; dres_track.fr(index_now)];
%             idInterp=[idInterp; dres_track.id(index_now)];
%             xInterp=[xInterp; dres_track.x(index_now)];
%             yInterp=[yInterp; dres_track.y(index_now)];
%             wInterp=[wInterp; dres_track.w(index_now)];
%             hInterp=[hInterp; dres_track.h(index_now)];
%             rInterp=[rInterp; dres_track.r(index_now)];
%             stateInterp=[stateInterp; dres_track.state(index_now)];
%         end
%     end
% end
% result.fr=frInterp;
% result.id=idInterp;
% result.x=xInterp;
% result.y=yInterp;
% result.w=wInterp;
% result.h=hInterp;
% result.r=rInterp;
% result.state=stateInterp;
% 
% end