%date:2016-6-1
%author:chenyanan
%ת����ע��������http://blog.csdn.net/u010278305

%% Initialization
clear all; close all; clc

debug=0;
time_interval=4;

picNameFormat='%06d';
picExt='.jpg';

seqNameAll = { ...   
    '02',   ...
    };

seq_dir={   ...
    'D:\smart_city\images_person\test\02\'  ...
    };

resultDir='results';

for seq_i=1:numel(seqNameAll)
    seqName=seqNameAll{seq_i};
    imgDir=seq_dir{seq_i};
    
    fprintf('seqName:%s.   \n',seqName);
    
    if debug
        x = input('Continue? Input (y) to continue. ','s');        
        if ~strcmp(x,'y')
            continue;
        end
    end
    
    %% read file
    detections=load([resultDir '/' seqName '.txt']);
    if isempty(detections)
        continue;
    end
    detections(:,1)=time_interval*detections(:,1);
    
    %% plot
    start_frame=min(detections(:,1));
    end_frame=max(detections(:,1));
    
    figure('name','Tracked Result');
    % set(gcf,'Renderer','painters');
    set(gcf,'Renderer','opengl');
    set(gcf,'NumberTitle','off');
    
    tic
    for i=start_frame:time_interval:end_frame
        detection_now=detections(detections(:,1)==i,:);
        i_tmp=i;
        imgName=[imgDir num2str(i_tmp,picNameFormat) picExt];
        while ~exist(imgName,'file')
            i_tmp=i_tmp-1;
            imgName=[imgDir num2str(i_tmp,picNameFormat) picExt];
        end
        im=imread(imgName);
        
        clf
        imagesc(im);
        set(gca,'XTick',[]);  set(gca,'YTick',[]);
        set(gca,'position',[0 0 1 1],'units','normalized')
        elapsedTime=toc;
        text(30,50,['Frame:' num2str(i) '   FPS:' num2str((i-start_frame)/elapsedTime)],...
            'color','r','FontSize',24,'FontWeight','bold');
        
        for j=1:size(detection_now,1)
            detcol=getColorFromID(detection_now(j,2));
            rectangle('Position',detection_now(j,3:6),'EdgeColor',detcol,'linewidth',3);
            text(detection_now(j,3),detection_now(j,4),num2str(detection_now(j,2)),...
                'color','r','FontSize',24,'FontWeight','bold');
        end
        
        pause(0.03)
    end
    
end
