% --------------------------------------------------------
% MDP Tracking
% Copyright (c) 2015 CVGL Stanford
% Licensed under The MIT License [see LICENSE for details]
% Written by Yu Xiang
% --------------------------------------------------------
%
% test on MOT benchmark
function MDP_debug

opt = globals();
is_train = opt.is_train;
time_interval=opt.time_interval;

mot2d_train_seqs = {'TUD-Stadtmitte', 'TUD-Campus', 'PETS09-S2L1', ...
    'ETH-Bahnhof', 'ETH-Sunnyday', 'ETH-Pedcross2', 'ADL-Rundle-6', ...
    'ADL-Rundle-8', 'KITTI-13', 'KITTI-17', 'Venice-2'};

test_seqs_name = opt.test_seqs_name;

seq_dir_base = opt.seq_dir_base;

% training and testing pairs
seq_idx_train = {{1,2,3}};
% seq_idx_test  = {{7, 8, 9, 10, 11, 12, 13, 14}};
seq_idx_test  = {num2cell(1:numel(test_seqs_name),1)};

N = numel(seq_idx_train);

test_time = 0;
for i = 1:N
    % training
    idx_train = seq_idx_train{i};
    
    if is_train
        % number of training sequences
        num = numel(idx_train);
        tracker = [];
        for j = 1:num
            fprintf('Training on sequence: %s\n', mot2d_train_seqs{idx_train{j}});
            tracker = MDP_train(idx_train{j}, tracker);
            fprintf('%d training examples after training on %s\n', ...
                size(tracker.f_occluded, 1), mot2d_train_seqs{idx_train{j}});
        end
    else
        % load tracker from file
        filename = sprintf('%s/%s_tracker.mat', opt.results, mot2d_train_seqs{idx_train{end}});
        object = load(filename);
        tracker = object.tracker;
        fprintf('load tracker from file %s\n', filename);
    end
    
    % testing
    idx_test = seq_idx_test{i};
    % number of testing sequences
    num = numel(idx_test);
    for j = 1:num
        fprintf('Testing on sequence: %s\n', test_seqs_name{idx_test{j}});
        tic;
        %for iter=1:4
        %    MDP_test_new(seq_dir{idx_test{j}}, mot2d_test_seqs{idx_test{j}}, tracker, iter);
        %end
        seq_name_now = test_seqs_name{idx_test{j}};
        seq_dir_now = fullfile(seq_dir_base, seq_name_now) ;
        MDP_test_new(seq_dir_now, seq_name_now, tracker, time_interval, 5, opt);
        % edit by chenyanan 2016.7.12
        trackInterp(seq_name_now, time_interval, opt);
        
        test_time_now = toc;
        fprintf('Testing time for sequence %s: %f\n', test_seqs_name{idx_test{j}}, test_time_now);
        test_time = test_time + test_time_now;
    end
end

fprintf('Total time for testing: %f\n', test_time);