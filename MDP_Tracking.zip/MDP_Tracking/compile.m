% --------------------------------------------------------
% MDP Tracking
% Copyright (c) 2015 CVGL Stanford
% Licensed under The MIT License [see LICENSE for details]
% Written by Yu Xiang
% --------------------------------------------------------
%
% compile cpp files
% change the include and lib path if necessary
function compile
globals();

include = ' -ID:\opencv\build\include\opencv\ -ID:\opencv\build\include\';
libPath = ' -LD:\opencv\build\x64\vc12\lib\';
lib = ' -lopencv_core249 -lopencv_highgui249 -lopencv_imgproc249 -lopencv_video249';
eval(['mex lk.cpp -O' include libPath lib]);

mex distance.cpp -O
mex imResampleMex.cpp -O 
mex warp.cpp -O

make;

disp('Compilation finished.');