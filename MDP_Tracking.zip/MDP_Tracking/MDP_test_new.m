% --------------------------------------------------------
% MDP Tracking
% Copyright (c) 2015 CVGL Stanford
% Licensed under The MIT License [see LICENSE for details]
% Written by Yu Xiang
% --------------------------------------------------------
%
% testing MDP
function MDP_test_new(seq_dir, seq_name, tracker, time_interval, iter, opt)

is_show = 0;   % set is_show to 1 to show tracking results in testing
is_save = 0;   % set is_save to 1 to save tracking result
is_text = 0;   % set is_text to 1 to display detailed info
is_pause = 0;  % set is_pause to 1 to debug

% opt = globals();
opt.is_text = is_text;
opt.exit_threshold = 0.7;

tracker.num = opt.num;
tracker.anchor= round(0.8*opt.num);

if is_show
    close all;
end

% read detections
filename = fullfile(opt.det_dir, [seq_name, '.txt']);
dres_det = read_mot2dres(filename);

%edit by chenyanan 2016.7.13
dres_det.fr(:)=floor((dres_det.fr(:)-1)/time_interval)+1;

% intialize tracker
% seq_num=[min([dres_det.fr]), max([dres_det.fr])];
if iter==1
    seq_num=[min([dres_det.fr]), round(max([dres_det.fr])/4)];
elseif iter==2
    seq_num=[round(max([dres_det.fr])/4), round(max([dres_det.fr])/2)];
elseif iter==3
    seq_num=[round(max([dres_det.fr])/2), round(max([dres_det.fr])*3/4)];
elseif iter==4
    seq_num=[round(max([dres_det.fr])*3/4), max([dres_det.fr])];
else
    seq_num=[min([dres_det.fr]), max([dres_det.fr])];
end
% seq_num=[1, 500];

seq_format=opt.seq_format;
dres_image = read_dres_image_new(seq_dir, seq_format, seq_num(1), time_interval);
I=dres_image.I{seq_num(1)};
tracker = MDP_initialize_test(tracker, size(I,2), size(I,1), dres_det, is_show);

% edit by chenyanan 2016.7.14
tracker_ori=tracker;
tracker=rmfield(tracker,{'factive', 'lactive', 'w_active', 'f_occluded', 'l_occluded', 'w_occluded'});

% for each frame
trackers = [];
id = 0;
% dres_track=struct('fr',{},'id',{},'x',{},'y',{},'w',{},'h',{},'r',{},'state',{});
for fr = seq_num(1):seq_num(2)
    if is_text
        fprintf('frame %d\n', fr);
    else
        fprintf('.');
        if mod(fr, 100) == 0
            fprintf('\n');
        end
    end
    
    %edit by chenyanan 2016.7.13
    clear dres_image;
    dres_image=read_dres_image_new(seq_dir, seq_format, fr, time_interval);
    
    % extract detection
    index = find(dres_det.fr == fr);
    dres = sub(dres_det, index);
    
    % nms
    boxes = [dres.x dres.y dres.x+dres.w dres.y+dres.h dres.r];
    index = nms_new(boxes, 0.6);
    dres = sub(dres, index);
    
    dres = MDP_crop_image_box(dres, dres_image.Igray{fr}, tracker);
    
    if is_show
        figure(1);
        
        % show ground truth
        if strcmp(seq_set, 'train') == 1
            subplot(2, 2, 1);
            show_dres(fr, dres_image.I{fr}, 'GT', dres_gt);
        end
        
        % show detections
        subplot(2, 2, 2);
        show_dres(fr, dres_image.I{fr}, 'Detections', dres_det);
    end
    
    % sort trackers     % edit by chenyanan 2016.7.12
    [trackers, index_track] = sort_release_trackers(trackers);
    
    % process trackers
    for i = 1:numel(index_track)
        ind = index_track(i);
        
        if trackers{ind}.state == 2
            % track target
            trackers{ind} = track(tracker_ori.w_occluded, fr, dres_image, dres, trackers{ind}, opt);
            % connect target
            if trackers{ind}.state == 3
                [dres_tmp, index] = generate_initial_index(trackers(index_track(1:i-1)), dres);
                dres_associate = sub(dres_tmp, index);
                trackers{ind} = associate(tracker_ori.w_occluded, fr, dres_image,  dres_associate, trackers{ind}, opt);
            end
        elseif trackers{ind}.state == 3
            % associate target
            [dres_tmp, index] = generate_initial_index(trackers(index_track(1:i-1)), dres);
            dres_associate = sub(dres_tmp, index);
            trackers{ind} = associate(tracker_ori.w_occluded, fr, dres_image, dres_associate, trackers{ind}, opt);
        end
    end
    
    % find detections for initialization
    [dres, index] = generate_initial_index(trackers, dres);
    for i = 1:numel(index)
        % extract features
        dres_one = sub(dres, index(i));
        f = MDP_feature_active(tracker, dres_one);
        % prediction edit by chenyanan 2016.7.14
        % label = svmpredict(1, f, tracker.w_active, '-q');
        label = svmpredict(1, f, tracker_ori.w_active, '-q');
        % make a decision
        if label < 0
            continue;
        end
        
        % reset tracker
        tracker.prev_state = 1;
        tracker.state = 1;
        id = id + 1;
        
        trackers{end+1} = initialize(fr, dres_image, id, dres, index(i), tracker);
    end
    
    % resolve tracker conflict
    trackers = resolve(trackers, dres, opt);
    
    if is_show
        % edit by chenyanan 2016.7.12
        dres_track = generate_results(trackers);
        
        figure(1);
        
        % show tracking results
        subplot(2, 2, 3);
        show_dres(fr, dres_image.I{fr}, 'Tracking', dres_track, 2);
        
        % show lost targets
        subplot(2, 2, 4);
        show_dres(fr, dres_image.I{fr}, 'Lost', dres_track, 3);
        
        if is_pause
            pause();
        else
            pause(0.01);
        end
    end
        
end

% edit by chenyanan 2016.7.12
dres_track = generate_results(trackers);

% write tracking results
filename = sprintf('%s/%s.txt', opt.results, seq_name);
fprintf('write results: %s\n', filename);
write_tracking_results(filename, dres_track, opt.tracked);

% save results
if is_save
    filename = sprintf('%s/%s_results.mat', opt.results, seq_name);
    save(filename, 'dres_track');
end

% sort trackers according to number of tracked frames
% release trackers according to lost time 
% opt.max_occlusion =30 
function tracker=fhandle(x)
if x.state==0 && isfield(x,'anchor')
%     dres = x.dres;
%     fields=fieldnames(dres);
%     for i=1:numel(fields)
%         dres.(fields{i})=dres.(fields{i})(1:end-30);
%     end
    tracker{1,1}.dres=structfun(@(x) x(1:end-30), x.dres, 'UniformOutput', 0);
    
    tracker{1,1}.streak_tracked=x.streak_tracked;
    tracker{1,1}.state=x.state;
    clear x;
else
    tracker{1,1}=x;
end
function [trackers, index] = sort_release_trackers(trackers)
sep = 10;
num = numel(trackers);
len = zeros(num, 1);
state = zeros(num, 1);
inactive_flag = zeros(num, 1);
if ~isempty(trackers)
    len=cellfun(@(x) x.streak_tracked, trackers);
    state=cellfun(@(x) x.state, trackers);
    
    len=len(:);
    state=state(:);
    inactive_flag = (state~=0);
    
    trackers=cellfun(@fhandle, trackers);
end

index1 = find(len > sep & inactive_flag);
[~, ind] = sort(state(index1));
index1 = index1(ind);

index2 = find(len <= sep & inactive_flag);
[~, ind] = sort(state(index2));
index2 = index2(ind);
index = [index1; index2];

% initialize a tracker
% dres: detections
function tracker = initialize(fr, dres_image, id, dres, ind, tracker)

if tracker.state ~= 1
    return;
else  % active
    
    % initialize the LK tracker
    tracker = LK_initialize(tracker, fr, id, dres, ind, dres_image);
    tracker.state = 2;
    tracker.streak_occluded = 0;
    tracker.streak_tracked = 0;
    
    % build the dres structure
    dres_one.fr = dres.fr(ind);
    dres_one.id = tracker.target_id;
    dres_one.x = dres.x(ind);
    dres_one.y = dres.y(ind);
    dres_one.w = dres.w(ind);
    dres_one.h = dres.h(ind);
    dres_one.r = dres.r(ind);
    dres_one.state = tracker.state;
    tracker.dres = dres_one;
end

% track a target
function tracker = track(w_occluded, fr, dres_image, dres, tracker, opt)

% tracked
if tracker.state == 2
    tracker.streak_occluded = 0;
    tracker.streak_tracked = tracker.streak_tracked + 1;
    tracker = MDP_value(w_occluded, tracker, fr, dres_image, dres, []);
    
    % check if target outside image
    [~, ov] = calc_overlap(tracker.dres, numel(tracker.dres.fr), dres_image, fr);
    if ov < opt.exit_threshold
        if opt.is_text
            fprintf('target outside image by checking boarders\n');
        end
        tracker.state = 0;
    end
end


% associate a lost target
function tracker = associate(w_occluded, fr, dres_image, dres_associate, tracker, opt)

% occluded
if tracker.state == 3
    tracker.streak_occluded = tracker.streak_occluded + 1;
    % find a set of detections for association
    [dres_associate, index_det] = generate_association_index(tracker, fr, dres_associate);
    tracker = MDP_value(w_occluded, tracker, fr, dres_image, dres_associate, index_det);
    if tracker.state == 2
        tracker.streak_occluded = 0;
    end
    
    if tracker.streak_occluded > opt.max_occlusion
        tracker.state = 0;
        if opt.is_text
            fprintf('target %d exits due to long time occlusion\n', tracker.target_id);
        end
    end
    
    % check if target outside image
    [~, ov] = calc_overlap(tracker.dres, numel(tracker.dres.fr), dres_image, fr);
    if ov < opt.exit_threshold
        if opt.is_text
            fprintf('target outside image by checking boarders\n');
        end
        tracker.state = 0;
    end
end


% resolve conflict between trackers
function trackers = resolve(trackers, dres_det, opt)

% collect dres from trackers
dres_track = [];
for i = 1:numel(trackers)
    tracker = trackers{i};
    % dres = sub(tracker.dres, numel(tracker.dres.fr));
    
    if tracker.state == 2 
        % edit by chenyanan
        dres = sub(tracker.dres, numel(tracker.dres.fr));  
        if isempty(dres_track)
            dres_track = dres;
        else
            dres_track = concatenate_dres(dres_track, dres);
        end
    end
end

% compute overlaps
num_det = numel(dres_det.fr);
if isempty(dres_track)
    num_track = 0;
else
    num_track = numel(dres_track.fr);
end

flag = zeros(num_track, 1);
for i = 1:num_track
    [~, o] = calc_overlap(dres_track, i, dres_track, 1:num_track);
    o(i) = 0;
    o(flag == 1) = 0;
    [mo, ind] = max(o);
    if mo > opt.overlap_sup
        num1 = trackers{dres_track.id(i)}.streak_tracked;
        num2 = trackers{dres_track.id(ind)}.streak_tracked;
        o1 = max(calc_overlap(dres_track, i, dres_det, 1:num_det));
        o2 = max(calc_overlap(dres_track, ind, dres_det, 1:num_det));
        
        if num1 > num2
            sup = ind;
        elseif num1 < num2
            sup = i;
        else
            if o1 > o2
                sup = ind;
            else
                sup = i;
            end
        end
        
        trackers{dres_track.id(sup)}.state = 3;
        trackers{dres_track.id(sup)}.dres.state(end) = 3;
        if opt.is_text
            fprintf('target %d suppressed\n', dres_track.id(sup));
        end
        flag(sup) = 1;
    end
end


% --------------------------------------------------------
% MDP Tracking
% Copyright (c) 2015 CVGL Stanford
% Licensed under The MIT License [see LICENSE for details]
% Written by Yu Xiang
% --------------------------------------------------------
%
% build the dres structure for images
function dres_image = read_dres_image_new(seq_dir, seq_format, index, time_interval)

if numel(index)==1
    index=[index index];
end

seq_length=index(2)-index(1)+1;
dres_image.x = zeros(seq_length, 1);
dres_image.y = zeros(seq_length, 1);
dres_image.w = zeros(seq_length, 1);
dres_image.h = zeros(seq_length, 1);
dres_image.I = cell(seq_length, 1);
dres_image.Igray = cell(seq_length, 1);

for i = index(1):index(2)
    i_tmp = time_interval*(i-1)+1;
    filename = fullfile(seq_dir, sprintf(seq_format, i_tmp));
    while ~exist(filename,'file')
        i_tmp=i_tmp-1;
        filename = fullfile(seq_dir, sprintf(seq_format, i_tmp));
        
        if abs(i_tmp - time_interval*(i-1)-1)>3*time_interval
            error('Image patherror.')
        end
    end
    %disp(filename);
    I = imread(filename);
    
    dres_image.x(i) = 1;
    dres_image.y(i) = 1;
    dres_image.w(i) = size(I, 2);
    dres_image.h(i) = size(I, 1);
    dres_image.I{i} = I;
    dres_image.Igray{i} = rgb2gray(I);
end