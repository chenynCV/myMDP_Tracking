% --------------------------------------------------------
% MDP Tracking
% Copyright (c) 2015 CVGL Stanford
% Licensed under The MIT License [see LICENSE for details]
% Written by Yu Xiang
% --------------------------------------------------------
function opt = globals()

opt.root = pwd;
opt.time_interval=4;

opt.seq_format='%06d.jpg';
opt.det_dir = fullfile(opt.root, 'det');

opt.test_seqs_name = { ...
%     '01',   ...
    '02',   ...
%     '03',   ...
%     '04',   ...
%     '05',   ...
%     '06',   ...
%     '07',   ...
%     '08',   ...
%     '09',   ...
%     '10',   ...
%     '11',   ...
%     '12',   ...
%     '13',   ...
%     '14'    ...
    };

opt.seq_dir_base= 'D:\smart_city\images_person\test\';

opt.results = 'results';
if exist(opt.results, 'dir') == 0
    mkdir(opt.results);
end

opt.final_results = 'refine';
if exist(opt.final_results, 'dir') == 0
    mkdir(opt.final_results);
end


addpath(fullfile(opt.root,'3rd_party','libsvm-3.20','matlab'));
addpath(fullfile(opt.root, '3rd_party','Hungarian'));


% tracking parameters
opt.num = 5;                 % number of templates in tracker (default 10)
opt.fb_factor = 30;           % normalization factor for forward-backward error in optical flow
opt.threshold_ratio = 0.6;    % aspect ratio threshold in target association
opt.threshold_dis = 2;        % distance threshold in target association, multiple of the width of target (default 3)
opt.threshold_box = 0.8;      % bounding box overlap threshold in tracked state (default 0.8)
opt.std_box = [30 60];        % [width height] of the stanford box in computing flow
opt.margin_box = [5, 2];      % [width height] of the margin in computing flow
opt.enlarge_box = [5, 3];     % enlarge the box before computing flow
opt.level_track = 1;          % LK level in association
opt.level =  1;               % LK level in association
opt.max_ratio = 0.9;          % min allowed ratio in LK
opt.min_vnorm = 0.2;          % min allowed velocity norm in LK
opt.overlap_box = 0.5;        % overlap with detection in LK
opt.patchsize = [24 12];      % patch size for target appearance
opt.weight_tracking = 1;      % weight for tracking box in tracked state
opt.weight_association = 1;   % weight for tracking box in lost state

% parameters for generating training data
opt.overlap_occ = 0.7;
opt.overlap_pos = 0.5;
opt.overlap_neg = 0.2;
opt.overlap_sup = 0.7;      % suppress target used in testing only

% training parameters
opt.is_train = 0;
opt.max_iter = 10000;     % max iterations in total
opt.max_count = 10;       % max iterations per sequence
opt.max_pass = 2;

% parameters to transite to inactive
opt.max_occlusion = 50; % 50
opt.exit_threshold = 0.95;
opt.tracked = 3; % 5