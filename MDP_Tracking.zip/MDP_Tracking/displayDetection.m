%date:2016-5-31
%author:chenyanan
%ת����ע��������http://blog.csdn.net/u010278305

%% Initialization
clear all; close all; clc

imgDir ='F:\smart_city\complete_test_sets\10\';
picNameFormat='%06d';
picExt='.jpg';

% read detections
detections=load('det/10.txt');

%% display
start_frame=4000;
end_frame=12600;
for i=start_frame:200:end_frame
    detection_now=detections(detections(:,1)==i,:);   
    i_tmp=i;
    imgName=[imgDir num2str(i_tmp,picNameFormat) picExt];
    while ~exist(imgName,'file')
        i_tmp=i_tmp-1;
        imgName=[imgDir num2str(i_tmp,picNameFormat) picExt];
    end
    im=imread(imgName);
    
    clf
    imagesc(im);
    set(gca,'XTick',[]);  set(gca,'YTick',[]);
    set(gca,'position',[0 0 1 1],'units','normalized')
    
    for j=1:size(detection_now,1)
        detcol=getColorFromID(j);
        rectangle('Position',detection_now(j,3:6),'EdgeColor',detcol,'linewidth',3);
    end
    
    pause(0.1)
    
    disp(i);
end



